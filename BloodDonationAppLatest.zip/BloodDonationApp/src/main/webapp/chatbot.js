
        window.$crisp = [];
        window.CRISP_WEBSITE_ID = "ec21cd9f-2c08-4f54-844c-0d14c4ed03d1";
        (function() {
            var d = document;
            var s = d.createElement("script");
            s.src = "https://client.crisp.chat/l.js";
            s.async = 1;
            d.getElementsByTagName("head")[0].appendChild(s);
        })();
   